#ifndef UTIL_ANNOT_H
#define UTIL_ANNOT_H
#include "main.h"
#include "util_i.h"

void initialize_exons_list(struct exons_list *a, int from, int to);
void get_gene_name(char *head, char *gname);

#endif /* UTIL_ANNOT_H */
